# Gameplay: Classic Push (chế độ duy nhất)

## Người xem hiểu trong 3–5 giây
Màn hình luôn có dòng lớn: **"CHAT BOY HOẶC GIRL ĐỂ ĐẨY!"** và dòng phụ "Tặng quà = đẩy mạnh hơn nhiều lần".

## Luật (toàn bộ)
1. Boy và Girl đứng đối diện. **Đẩy đối thủ ra khỏi sân trước thì thắng.**
2. Người xem chỉ có 2 hành động:
   - Chat đúng `BOY` hoặc `GIRL` (không phân biệt hoa/thường) → chọn đội và **+1 điểm**.
   - Tặng quà → cộng cho đội mà người đó đã chọn: nhỏ **+10**, vừa **+30**, lớn **+100** (nhân số lượng).
3. Vị trí hai nhân vật = **chênh lệch điểm**. Dẫn trước **60 điểm** thì đối thủ bị đẩy ra khỏi sân, thắng ngay. (Số 60 chỉnh được trong `leadToWin`.)
4. Hết **90 giây** (chỉnh 60–120): bên dẫn điểm thắng. Nếu hòa: **Điểm vàng**, ai ghi điểm trước thắng.
5. Kết quả hiện 6 giây, sau đó tự đếm ngược 3-2-1 và vào vòng mới.

## Thứ tự một trận
Đếm ngược 3-2-1 → ĐẨY! (90 giây) → kết quả → vòng mới. Không có giai đoạn nào khác.

## Phản hồi cho mỗi hành động
| Hành động | Hình ảnh | Âm thanh |
|---|---|---|
| Chat BOY/GIRL | Dòng "Tên · ĐỘI +1" màu đội, nhân vật bị đẩy nhẹ, bụi nhỏ | Tiếng "tích" (Boy trầm, Girl cao) |
| Quà | Dòng lớn "Tên tặng X +10/30/100", nhân vật bị đẩy mạnh, nhiều hạt, rung màn hình (quà lớn rung mạnh hơn) | Nhạc chuông đi lên (quà lớn dài hơn) |
| Sắp thắng (dẫn 75%) | Biểu ngữ đỏ nhấp nháy lớn "X SẮP BỊ ĐẨY RA!" | Còi hai nốt |
| 10 giây cuối | Đồng hồ to, đỏ, nhịp đập | Bíp mỗi giây |
| Thắng | Màn hình "X THẮNG!" + lý do + tỷ số, rung mạnh | Nhạc chiến thắng |

## HUD (từ trên xuống)
Dòng hướng dẫn lớn · đồng hồ rất lớn · **thanh sức mạnh một thanh chia đôi xanh/hồng** (điểm chia = đúng vị trí nhân vật) kèm điểm hai đội · 3 dòng hoạt động gần nhất (tên + điểm cộng) · dòng chú thích điểm ở đáy.

## Đã bỏ hoàn toàn
Nhiều chế độ (Survival, Boss, Chaos, King of Arena, Tug of War, Viewer Champion, Special Event), kỹ năng, combo, hazard, danh hiệu, vote chế độ, diminishing returns, comeback boost, giới hạn điểm theo ngày, MVP trong HUD.
Chống spam chỉ còn: 1 điểm chat mỗi người mỗi giây; và 1 sự kiện không được cộng quá 300 điểm (để một quà không tự kết thúc trận).

## Quyết định cần bạn xác nhận
- **Quà từ người chưa chọn đội** hiện đang **bị bỏ qua** và hiện nhắc "chat BOY hoặc GIRL trước". Có thể đổi `giftWithoutTeam` thành `"boy"` hoặc `"girl"` nếu bạn muốn không bỏ sót quà.
- Mức điểm quà (10/30/100) và ánh xạ quà TikTok → nhỏ/vừa/lớn do bạn quyết định; hệ thống không quy đổi quà thành tiền.

## Áp dụng vào dự án của bạn (bản AI Studio, TypeScript)
`LiveBridge/engine/matchEngine.ts` hiện dài ~1.770 dòng và còn toàn bộ các hệ thống phía trên (8 chế độ trong `GameModeId`, hazard, combo, kỹ năng, danh hiệu). Hướng sạch nhất: thay bằng engine ~130 dòng `engine/classicPush.js` (đã có test), khóa `GameModeId` chỉ còn `ClassicPush`, ẩn các trang Skill/Mode trong Admin, và đổi `LivestreamPortraitView.tsx` theo HUD ở trên. Mình chưa sửa trực tiếp vào code của bạn vì môi trường này không cài được thư viện để chạy thử dự án đó.
