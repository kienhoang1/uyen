'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { create, parseTeam } = require('../engine/classicPush');
const U = (id) => ({ id, name: 'User ' + id });
function active(cfg) { const ev = []; const g = create(cfg, (e) => ev.push(e)); g.tick(g.cfg.countdownSec + 0.01); return { g, ev }; }

test('chi BOY/GIRL la lenh (khong phan biet hoa thuong, co khoang trang)', () => {
  assert.equal(parseTeam(' boy '), 'BOY'); assert.equal(parseTeam('Girl'), 'GIRL');
  assert.equal(parseTeam('boy thang di'), null); assert.equal(parseTeam('ATTACK'), null); assert.equal(parseTeam(5), null);
});
test('dem nguoc 3 giay roi vao tran; chat luc dem nguoc khong tinh diem', () => {
  const g = create({}, () => {});
  assert.equal(g.chat(U(1), 'BOY', 0), false); assert.equal(g.state.B, 0);
  g.tick(3.01); assert.equal(g.state.phase, 'active'); assert.equal(g.state.t, g.cfg.matchSec);
});
test('chat +1 diem, cooldown 1 giay moi nguoi, nguoi khac khong bi anh huong', () => {
  const { g } = active();
  assert.ok(g.chat(U(1), 'BOY', 1000)); assert.equal(g.chat(U(1), 'BOY', 1500), false);
  assert.ok(g.chat(U(1), 'BOY', 2100)); assert.ok(g.chat(U(2), 'GIRL', 1500));
  assert.deepEqual([g.state.B, g.state.G], [2, 1]);
});
test('qua manh hon chat: nho 10, vua 30, lon 100 (nhan so luong), thuoc doi da chon', () => {
  const { g } = active({ leadToWin: 10000 });
  g.chat(U(1), 'GIRL', 0);
  g.gift(U(1), 'small'); g.gift(U(1), 'medium'); g.gift(U(1), 'large', 2);
  assert.equal(g.state.G, 1 + 10 + 30 + 200);
  assert.equal(g.state.B, 0);
});
test('qua tu nguoi chua chon doi: mac dinh bo qua va bao hieu', () => {
  const { g, ev } = active();
  assert.equal(g.gift(U(9), 'large'), false);
  assert.ok(ev.some((e) => e.type === 'gift_no_team')); assert.equal(g.state.B + g.state.G, 0);
});
test('1 su kien khong the ket thuc tran: gioi han diem moi su kien', () => {
  const { g } = active({ leadToWin: 1000, maxPointsPerEvent: 300 });
  g.chat(U(1), 'BOY', 0); g.gift(U(1), 'large', 50);
  assert.equal(g.state.B, 301);
});
test('day ra khoi san khi dan truoc du diem; vi tri luon trong 0..100', () => {
  const { g, ev } = active({ leadToWin: 5 });
  for (let i = 0; i < 5; i++) g.chat(U(i), 'GIRL', 0);
  assert.equal(g.state.phase, 'result'); assert.equal(g.state.winner, 'GIRL');
  assert.deepEqual(ev.find((e) => e.type === 'win'), { type: 'win', team: 'GIRL', reason: 'ring-out' });
  for (let i = 0; i < 100; i++) g.tick(0.1);
  assert.ok(g.state.pos >= 0 && g.state.pos <= 100);
});
test('canh bao lon dung 1 lan khi doi bi day gan het san', () => {
  const { g, ev } = active({ leadToWin: 20 });
  for (let i = 0; i < 16; i++) g.chat(U(i), 'BOY', 0);
  assert.equal(ev.filter((e) => e.type === 'warning').length, 1);
  assert.equal(ev.find((e) => e.type === 'warning').team, 'GIRL');
  assert.equal(g.state.warning, 'GIRL');
});
test('het gio: ben dan diem thang; hoa -> diem vang, ai ghi truoc thang', () => {
  let r = active({ matchSec: 5 }); r.g.chat(U(1), 'BOY', 0); r.g.tick(5.1);
  assert.equal(r.g.state.winner, 'BOY');
  r = active({ matchSec: 5 }); r.g.tick(5.1);
  assert.equal(r.g.state.phase, 'sudden');
  r.g.chat(U(1), 'GIRL', 0); assert.equal(r.g.state.winner, 'GIRL'); assert.equal(r.ev.find((e) => e.type === 'win').reason, 'golden');
});
test('tu dong vao van moi sau ket qua, diem reset, so tran thang giu nguyen', () => {
  const { g } = active({ leadToWin: 2, resultSec: 2 });
  g.chat(U(1), 'BOY', 0); g.chat(U(2), 'BOY', 0);
  assert.equal(g.state.wins.BOY, 1); g.tick(2.1);
  assert.equal(g.state.phase, 'countdown'); assert.equal(g.state.round, 2);
  assert.deepEqual([g.state.B, g.state.G, g.state.pos], [0, 0, 50]); assert.equal(g.state.wins.BOY, 1);
});
