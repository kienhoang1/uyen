'use strict';
// CLASSIC PUSH - luat choi duy nhat, don gian nhat co the. Khong phu thuoc thu vien.
// Dung duoc trong Node (require) va trinh duyet (window.ClassicPush).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ClassicPush = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  const DEFAULTS = {
    countdownSec: 3,
    matchSec: 90,
    resultSec: 6,
    leadToWin: 60,
    warnRatio: 0.75,
    finalSeconds: 10,
    chatPoints: 1,
    chatCooldownMs: 1000,
    giftPoints: { small: 10, medium: 30, large: 100 },
    maxPointsPerEvent: 300,
    giftWithoutTeam: 'ignore',
  };

  function parseTeam(text) {
    if (typeof text !== 'string') return null;
    const t = text.trim().toUpperCase();
    return t === 'BOY' ? 'BOY' : t === 'GIRL' ? 'GIRL' : null;
  }

  function create(cfg = {}, emit = () => {}) {
    const c = { ...DEFAULTS, ...cfg, giftPoints: { ...DEFAULTS.giftPoints, ...(cfg.giftPoints || {}) } };
    const s = { phase: 'countdown', t: c.countdownSec, B: 0, G: 0, pos: 50, winner: null, reason: '', warning: null, round: 1, wins: { BOY: 0, GIRL: 0 } };
    const team = {}, last = {};
    let warned = null, lastInt = Math.ceil(s.t);
    const lead = () => s.B - s.G;
    const target = () => 50 + 50 * Math.max(-1, Math.min(1, lead() / c.leadToWin));
    const setPhase = (p, t) => { s.phase = p; s.t = t; lastInt = Math.ceil(t); emit({ type: 'phase', phase: p }); };

    function win(w, reason) {
      s.winner = w; s.reason = reason; s.warning = null; s.wins[w]++;
      setPhase('result', c.resultSec);
      emit({ type: 'win', team: w, reason });
    }
    function check() {
      const l = lead();
      if (Math.abs(l) >= c.leadToWin) return win(l > 0 ? 'BOY' : 'GIRL', 'ring-out');
      if (s.phase === 'sudden' && l !== 0) return win(l > 0 ? 'BOY' : 'GIRL', 'golden');
      const behind = l > 0 ? 'GIRL' : 'BOY';
      if (Math.abs(l) >= c.leadToWin * c.warnRatio) {
        if (warned !== behind) { warned = behind; s.warning = behind; emit({ type: 'warning', team: behind }); }
      } else { warned = null; s.warning = null; }
    }
    function add(tm, pts, user, kind, extra) {
      if (s.phase !== 'active' && s.phase !== 'sudden') return false;
      pts = Math.min(pts, c.maxPointsPerEvent);
      if (tm === 'BOY') s.B += pts; else s.G += pts;
      emit({ type: 'point', team: tm, points: pts, user, kind, ...extra });
      check();
      return true;
    }

    function chat(user, text, now = Date.now()) {
      const tm = parseTeam(text);
      if (!tm) return false;
      if (last[user.id] && now - last[user.id] < c.chatCooldownMs) return false;
      last[user.id] = now; team[user.id] = tm;
      return add(tm, c.chatPoints, user.name, 'chat');
    }
    function gift(user, tier, qty = 1, label = '') {
      let tm = team[user.id];
      if (!tm) {
        if (c.giftWithoutTeam === 'boy') tm = 'BOY'; else if (c.giftWithoutTeam === 'girl') tm = 'GIRL';
        else { emit({ type: 'gift_no_team', user: user.name }); return false; }
      }
      const base = c.giftPoints[tier] || c.giftPoints.small;
      return add(tm, base * Math.max(1, qty | 0), user.name, 'gift', { tier, label });
    }

    function tick(dt) {
      if (s.phase === 'countdown' || s.phase === 'active' || s.phase === 'result') {
        s.t -= dt;
        const n = Math.ceil(s.t);
        if (n !== lastInt && n >= 0) {
          lastInt = n;
          if (s.phase === 'countdown' && n > 0) emit({ type: 'count', n });
          if (s.phase === 'active' && n <= c.finalSeconds && n > 0) emit({ type: 'final', n });
        }
        if (s.t <= 0) {
          if (s.phase === 'countdown') { setPhase('active', c.matchSec); emit({ type: 'go' }); }
          else if (s.phase === 'active') {
            const l = lead();
            if (l !== 0) win(l > 0 ? 'BOY' : 'GIRL', 'time');
            else { setPhase('sudden', 0); s.warning = null; warned = null; }
          } else {
            s.B = 0; s.G = 0; s.pos = 50; s.winner = null; s.reason = ''; s.warning = null; warned = null; s.round++;
            setPhase('countdown', c.countdownSec);
          }
        }
      }
      s.pos += (target() - s.pos) * (1 - Math.exp(-dt * 6));
      return s;
    }
    return { state: s, cfg: c, tick, chat, gift, teamOf: (id) => team[id] || null };
  }
  return { create, parseTeam, DEFAULTS };
});
